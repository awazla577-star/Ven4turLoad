.class Lcom/fakelag/veo/MainActivity$100000000;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakelag/veo/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lcom/fakelag/veo/MainActivity;


# direct methods
.method constructor <init>(Lcom/fakelag/veo/MainActivity;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lcom/fakelag/veo/MainActivity$100000000;->this$0:Lcom/fakelag/veo/MainActivity;

    return-void
.end method

.method static access$0(Lcom/fakelag/veo/MainActivity$100000000;)Lcom/fakelag/veo/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/fakelag/veo/MainActivity$100000000;->this$0:Lcom/fakelag/veo/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/CompoundButton;",
            "Z)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 59
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, v0

    iget-object v4, v4, Lcom/fakelag/veo/MainActivity$100000000;->this$0:Lcom/fakelag/veo/MainActivity;

    invoke-static {v4}, Lcom/fakelag/veo/MainActivity;->access$L1000005(Lcom/fakelag/veo/MainActivity;)Z

    move-result v4

    if-eqz v4, :cond_0

    .line 71
    :goto_0
    return-void

    .line 61
    :cond_0
    move-object v4, v0

    iget-object v4, v4, Lcom/fakelag/veo/MainActivity$100000000;->this$0:Lcom/fakelag/veo/MainActivity;

    invoke-static {v4}, Lcom/fakelag/veo/MainActivity;->access$L1000004(Lcom/fakelag/veo/MainActivity;)Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_1

    .line 62
    move-object v4, v0

    iget-object v4, v4, Lcom/fakelag/veo/MainActivity$100000000;->this$0:Lcom/fakelag/veo/MainActivity;

    const-string v5, "Vui l\u00f2ng ch\u1ecdn Game c\u1ea7n Boost!"

    invoke-static {v4, v5}, Lcom/fakelag/veo/MainActivity;->access$1000017(Lcom/fakelag/veo/MainActivity;Ljava/lang/String;)V

    .line 63
    move-object v4, v0

    iget-object v4, v4, Lcom/fakelag/veo/MainActivity$100000000;->this$0:Lcom/fakelag/veo/MainActivity;

    invoke-static {v4}, Lcom/fakelag/veo/MainActivity;->access$L1000002(Lcom/fakelag/veo/MainActivity;)Landroid/widget/Switch;

    move-result-object v4

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/widget/Switch;->setChecked(Z)V

    .line 64
    goto :goto_0

    .line 67
    :cond_1
    move v4, v2

    if-eqz v4, :cond_2

    .line 68
    move-object v4, v0

    iget-object v4, v4, Lcom/fakelag/veo/MainActivity$100000000;->this$0:Lcom/fakelag/veo/MainActivity;

    invoke-static {v4}, Lcom/fakelag/veo/MainActivity;->access$1000008(Lcom/fakelag/veo/MainActivity;)V

    .line 71
    :goto_1
    goto :goto_0

    .line 70
    :cond_2
    move-object v4, v0

    iget-object v4, v4, Lcom/fakelag/veo/MainActivity$100000000;->this$0:Lcom/fakelag/veo/MainActivity;

    invoke-static {v4}, Lcom/fakelag/veo/MainActivity;->access$1000010(Lcom/fakelag/veo/MainActivity;)V

    .line 71
    move-object v4, v0

    iget-object v4, v4, Lcom/fakelag/veo/MainActivity$100000000;->this$0:Lcom/fakelag/veo/MainActivity;

    const-string v5, "\u0110\u00e3 t\u1eaft Engine"

    invoke-static {v4, v5}, Lcom/fakelag/veo/MainActivity;->access$1000017(Lcom/fakelag/veo/MainActivity;Ljava/lang/String;)V

    goto :goto_1
.end method
