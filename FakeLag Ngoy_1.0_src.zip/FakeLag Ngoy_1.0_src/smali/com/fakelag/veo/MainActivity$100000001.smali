.class Lcom/fakelag/veo/MainActivity$100000001;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/fakelag/veo/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# instance fields
.field private final this$0:Lcom/fakelag/veo/MainActivity;


# direct methods
.method constructor <init>(Lcom/fakelag/veo/MainActivity;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lcom/fakelag/veo/MainActivity$100000001;->this$0:Lcom/fakelag/veo/MainActivity;

    return-void
.end method

.method static access$0(Lcom/fakelag/veo/MainActivity$100000001;)Lcom/fakelag/veo/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/fakelag/veo/MainActivity$100000001;->this$0:Lcom/fakelag/veo/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 80
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lcom/fakelag/veo/MainActivity$100000001;->this$0:Lcom/fakelag/veo/MainActivity;

    invoke-static {v3}, Lcom/fakelag/veo/MainActivity;->access$1000014(Lcom/fakelag/veo/MainActivity;)V

    return-void
.end method
