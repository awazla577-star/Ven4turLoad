.class public final Lcom/fakelag/veo/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/fakelag/veo/R$attr;,
        Lcom/fakelag/veo/R$drawable;,
        Lcom/fakelag/veo/R$id;,
        Lcom/fakelag/veo/R$layout;,
        Lcom/fakelag/veo/R$string;,
        Lcom/fakelag/veo/R$style;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    .line 35
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
